# SNAKE 2

A modern take on the classic arcade game featuring 200 structured phases, portal mechanics, animated items, and an ultra-hard random endless mode unlocked after defeating the main campaign.

## 🚀 How to Play
1. Clone or download this repository to your local machine.
2. Open the `index.html` file directly in any modern web browser (Chrome, Firefox, Edge, Safari).
3. Use the keyboard arrows (`W`, `A`, `S`, `D`) to control the direction or tap the on-screen touch controls if you are playing on a mobile device.

## 🛠️ Features
- **Engine Performance:** Completely optimized frame rendering loop uncoupled from the game logic grid to prevent browser stuttering.
- **Dual-Storage Save Engine:** Saves your current progress simultaneously using `LocalStorage` and `IndexedDB` to guarantee no data loss if one system fails or is restricted by the browser.
- **Visual Sizing:** Responsive canvas layout adapting dynamically to mobile screens and desktops alike.
- **Post-Game Challenge:** Defeating the 200 standard levels unlocks the infinite random mode featuring dynamic obstacle generation and hostile monsters.

## 📄 License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
